#include "cats.h"

int main(void)
{
	int option = 0;

	
	do
	{
		option = validate_menu_option();

		process_option(option);
	} while (option != SCHRODINGER);

	return 0;
}
