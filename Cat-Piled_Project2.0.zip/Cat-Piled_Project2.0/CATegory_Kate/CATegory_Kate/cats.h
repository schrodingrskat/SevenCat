#ifndef CATEGORY_KATE
#define CATEGORY_KATE
#define _CRT_SECURE_NO_WARNINGS

#define COLBY 1
#define PAPYRUS 2
#define OXNARD 3
#define DUTCH 4
#define FISHER 5
#define ARTHUR 6
#define SCHRODINGER 7

#include <stdio.h>



//beef with papyrus
int dutch();

//existing in wsu
int fisher();

//fishing for compliments
int arthur();

#endif