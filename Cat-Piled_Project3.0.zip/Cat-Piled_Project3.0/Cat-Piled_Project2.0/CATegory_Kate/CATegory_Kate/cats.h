// A SEVENCAT PRODUCTION
// COUGAR WELCOMING COMMITTI-KITTIES **local cats helping cougs**
// An app to support students -- via Bri's cats!
// ft. Schrodinger the Cat
// Credits: Bri Weik and Kate Prophet

#ifndef CATEGORY_KATE
#define CATEGORY_KATE
#define _CRT_SECURE_NO_WARNINGS

#define COLBY 1
#define PAPYRUS 2
#define OXNARD 3
#define DUTCH 4
#define FISHER 5
#define ARTHUR 6
#define SCHRODINGER 7

#include <stdio.h>

//loop function headers
void displaymenu(void);
int gettheoption(void);
int validate(void);
void process(int option);

#endif