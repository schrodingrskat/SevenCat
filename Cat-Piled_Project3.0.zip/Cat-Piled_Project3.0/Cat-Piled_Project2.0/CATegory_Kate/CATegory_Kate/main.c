#include "cats.h"

// A SEVENCAT PRODUCTION
// COUGAR WELCOMING COMMITTI-KITTIES **local cats helping cougs**
// An app to support students -- via Bri's cats!
// ft. Schrodinger the Cat
// Credits: Bri Weik and Kate Prophet

int main(void)
{
	int option = 0;

	//Menu/validation loop
	
	do
	{
		option = validate();

		process(option);
	} while (option != SCHRODINGER);

	return 0;
}
