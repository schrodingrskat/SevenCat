// A SEVENCAT PRODUCTION
// COUGAR WELCOMING COMMITTI-KITTIES **local cats helping cougs**
// An app to support students -- via Bri's cats!
// ft. Schrodinger the Cat
// Credits: Bri Weik and Kate Prophet

#include "cats.h"

//main menu

void displaymenu(void)
{
	printf("            /\\_/\\\n");
	printf("           ( o.o )\n");
	printf("            > ^ < \n\n");
	printf("COUGAR WELCOMING COMMITTI-KITTIES\n**local cats helping cougs**\n");
	printf("An app to support students -- via Bri's cats!\n\nSelect an option below for wisdom:\n\n");
	printf("1. Computer help with Colby!\n");
	printf("2. Existing in Pullman with Papyrus!\n");
	printf("3. Existential crisis with Oxnard -_-\n");
	printf("4. Help with Papyrus yelling at Dutch???\n");
	printf("5. Existing at WSU with Fisher! :D\n");
	printf("6. Fishing for compliments with Arthur B)\n");
	printf("7. Schrodinger to exit***\n\n");
}

//input
int gettheoption(void)
{
	int option = 0;

	scanf("%d", &option);

	return option;
}

//validation
int validate(void)
{
	int option = 0;

	do
	{
		displaymenu();
		option = gettheoption(); 
	} while (option < COLBY || option > SCHRODINGER); 

	return option;
}

//input processing per CATegory
void process(int option)
{
	switch (option)
	{
	case COLBY: printf("\n\nCOLBY\n\n\n");
		printf("You know, I'm not very booksmart yet, but I heard this guy Andy is pretty knowledgeable.\n");
		printf("Here, take his email: aofallon@wsu.edu\n");
		break;
	case PAPYRUS: printf("\n\nPAPYRUS\n\n\n");
		printf("Hey hi! I know things about the whole town! Let me tell you the things I know:\n");
		int papy_option = 0;
		do
		{

			printf("1. Food\n");
			printf("2. Shopping\n");
			printf("3. Activities\n");
			printf("4. Events\n");
			printf("5. Weird Things The Locals Do\n");
			printf("6. No more questions, thanks.\n");
			
			scanf("%d", &papy_option);
			if (papy_option == 1)
			{
				printf("Food is one of my ALL TIME FAVORITE THINGS.\n");
				printf("My parents looooove O-Ramen! Did you know Oron (the owner) used to be a bartender at Etsi, before moving to Japan to learn the art of ramen before bringing it back here? What a cool guy!\n");
				printf("We also love to support Miss Huddy's barbecue. They're only open on Sundays every other weekend, but they pour so much love into their central-Texan barbecue, I scream for turkey every time!\n");
				printf("Miss Huddy's is located just outside of the Paradise Creek Trailside Taproom, which is great because you can drink beer while you wait in line! The whole experience is worth it!\n");
			}
			else if (papy_option == 2)
			{
				printf("It may feel like your only option in town is Walmart, but there are tons of local businesses that we love to support instead!\n");
				printf("For clothing, we really like Flirt downtown. And Palouse Games is really cool if you're looking for a new hobby! Tell Walter I said hi!!\n");
			}
			else if (papy_option == 3)
			{
				printf("Pullman's a pretty quiet town, which is a lot of its appeal. But there are some great places to go hiking nearby, like Moscow Mountain or Kamiak Butte.\n");
				printf("I'm more of an indoor cat myself, I prefer to appreciate nature from the comfort of my cat tree rather than a real one. There's less bird poop in here.\n");
			}
			else if (papy_option == 4)
			{
				printf("If you're looking to do something off-campus, there are TWO different theatres in down that frequently do shows! RTOP is really fun, they do a lot of musicals!\n");
			}
			else if (papy_option == 5)
			{
				printf("Back when it was still Mom/Dad's Weekend instead of Family Weekend, some of the high school kids would drive up to campus");
				printf("just to watch the moms do the walk of shame from the frat houses in the morning.\n");
				printf("Did you know that condom sales in Pullman were at their highest during Mom's Weekends? There's an uncomfortable fun fact for you.\n");
			}

			printf("\nAnything else?\n\n");
		} while (papy_option != 6);

	
		break;

		//next baby
	case OXNARD: printf("\n\nOXNARD\n\n\n");
		
		int ox_option = 0;

		
			printf("Hello, I'm Oxnard! But my mom calls me The Former President of the United States, Barack Ob-Oxnard.\n");
			printf("I heard you're feeling a little stressed out, is there something I can help with? \n\n");

		do
		{
			printf("1. Health Resources\n");
			printf("2. Meditation\n");
			printf("3. Big Streeeeeetch\n");
			printf("4. Bits of Motivation\n");
			printf("5. Scream into the Void\n");
			printf("6. Pet the kittyn\n");		//This will be for when we make the app, we'll get a pet the kitty thing figured out
			printf("7. No more questions, thanks.\n");


			scanf("%d", &ox_option);

			if (ox_option == 1)
			{
				printf("I'm sorry you aren't feeling well. Here's a list of resources that might be able to help you!\n");
				printf("https://cougarhealth.wsu.edu/");
				printf("\n\n");
			}
			else if (ox_option == 2)
			{
				printf("Great choice! Meditiation's one of my favorites. It's like tiny mind naps.\n");
				printf("Close your eyes, empty your mind, focus on your breath. Let's count to three.\n"); //find a timed, automated counter
			}
			else if (ox_option == 3)
			{
				printf("Papyrus does great big stretches. I'm small, but I try my best too!\n");
				printf("Reach your arms straight up above your head, and hold it for five seconds.\n");
				printf("Now slowly let them down, until you're reach out to both sides. Hold that for five seconds.\n");
			}
			else if (ox_option == 4)
			{
				printf("You got this! I believe in you!\n");
			}
			else if (ox_option == 5)
			{
				printf("Sometimes we all need to scream into the void. Here, let me give you a little void: \n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
			}
			else if (ox_option == 6)
			{
				printf("  /\\_/\\  (\n");
				printf(" (^ .^) _)\n");
				printf("  \\''/ (\n");
				printf("  (| |)\n");
				printf("(__d b__)\n");
			}
			printf("Anthing else?\n\n");
		} while (ox_option != 7);
		break;

		//next baby
	case DUTCH:   printf("***Why is Papyrus yelling at Dutch??***\n\n");
		printf("***Ah, it is because Dutch is eating the oven mitts.***\n\n");
		printf("***... WHY IS DUTCH EATING THE OVEN MITTS???***\n\n");
		break;
	case FISHER: printf("\n\nFISHER\n\n\n");
		    printf("      |\\      _,,,---,,_\n");
			printf("ZZZzz / , `. - '`' - .; -;; , _\n");
			printf("     | , 4 - ) ) - , _., \\ (`'-'\n");
			printf("      '---''(_/--'  `-'\\_)  \n\n");
			printf("*** Looks like he's asleep. Fisher's advice for students at WSU is to nap often. ***\n");
			printf("Do you want to wake him up?\n\nYes = 1\nNo = 2\n\n");
			int decision1 = 0;
			scanf("%d", &decision1);
			if (decision1 == 1)
			{
				printf("You monster.\n\nWhat do you need to know?\n\n");
				int decision2 = 0;
				do
				{
					printf("Select a question to ask Fisher:\n\n");
					printf("1. Where can I go to nap --I mean study?\n2. Where has the best snacks?\n3. How do I avoid hills and still be on time?\n");
					printf("4. No more questions, thanks.\n");
					scanf("%d", &decision2);
					if (decision2 == 1)
					{
						printf("Fisher: ""My favorite place to nap is on Bri's laptop -- while she's working on it. It's so warm!\n");
						printf("^~^ As for studying... also on Bri's laptop.""\n\n");
					}
					else if (decision2 == 2)
					{
						printf("Fisher: ""The Office has surprisingly good Mai Tai's! ...Wait did you mean food?""\n");
					}
					else if (decision2 == 3)
					{
						printf("Fisher: ""... You don't, sorry."" :/\n");
					}
				} while (decision2 != 4);
			}
			else
			{
				printf("Kind of you. Maybe try back again later.\n");
			}
		break;

		//next baby
	case ARTHUR: printf("\n\nArthur: ""Trying to get compliments? Just bend and snap, baby.""\n\n\n");
		break;
	case SCHRODINGER: printf("\n\nDead or alive? You are now closing the box, goodbye.\n\n\n");
		break;
	default: printf("\n\ninvalid option. that is a dog. pick a cat.\n\n\n");
		break;
	}

	//exit
	printf("Back to menu!\n\n");
}
